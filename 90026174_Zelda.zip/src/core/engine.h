#ifndef ENGINE_H
#define ENGINE_H

void InitProgram();

#endif