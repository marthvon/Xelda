#include <stdio.h>

#include "core/engine.h"

int main(int argc, char** argv) {    
    
    InitProgram();

    return 0;
}