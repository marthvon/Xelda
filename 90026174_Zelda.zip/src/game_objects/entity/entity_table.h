#ifndef ENTITY_TABLE_H
#define ENTITY_TABLE_H

typedef enum {
    BACKGROUND_ENTITY,
    PLAYER_ENTITY,
    STATUE_ENTITY,
    ENEMY_SPIDER_ENTITY
} EntityInstance;

#endif