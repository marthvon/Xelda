#ifndef EVENTS_TABLE_H
#define EVENTS_TABLE_H

typedef enum {
    SWORD_TAKEN_TRIGGERED,
    MAX_EVENTS_COUNT
} EventReference;

#endif