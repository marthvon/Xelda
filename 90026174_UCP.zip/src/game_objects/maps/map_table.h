#ifndef MAPS_TABLE_H
#define MAPS_TABLE_H

typedef enum {
    VOID_MAP = -1,
    START_MAP,
    SOUTH_BOROUGH_MAP,
    MAX_SCENE_COUNT
} MapInstance;

#endif