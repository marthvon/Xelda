#include "bomb_entity.h"

Entity* ReadyBomb(const float position_x, const float position_y, Map* created_by) {

    return NULL;
}

void ExitBomb(Entity* entity) {

}

void ProcessBomb(Entity* entity, const float delta) {

}
