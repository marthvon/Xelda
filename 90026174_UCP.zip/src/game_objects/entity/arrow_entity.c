#include "arrow_entity.h"

Entity* ReadyArrow(const float position_x, const float position_y, Map* created_by) {

    return NULL;
}

void ExitArrow(Entity* entity) {

}

void ProcessArrow(Entity* entity, const float delta) {

}
