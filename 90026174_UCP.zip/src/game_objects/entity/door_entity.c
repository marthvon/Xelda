#include "door_entity.h"

Entity* ReadyDoor(const float position_x, const float position_y, Map* created_by) {

    return NULL;
}

void ExitDoor(Entity* entity) {

}

void ProcessDoor(Entity* entity) {

}
