#ifndef ENGINE_H
#define ENGINE_H

void InitProgram(int map_id);

#endif