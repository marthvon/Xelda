#ifndef TIMER_H
#define TIMER_H

void InitTimer();
const float TickTimer();
const float GetDeltaTime();
void ResetTimer();

#endif